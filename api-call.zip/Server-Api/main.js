const express =require("express");
const app =express();
const bodyparser=require("body-parser");
const Railway =require("./server/Router/auth")
const mongoose = require('mongoose');


app.use(bodyparser())
// Routes

app.use(Railway.Router)


const port = process.env.PORT || 5000;

//Set up default mongoose connection
var mongoDB = 'mongodb+srv://db:db@cluster0.11yl9.mongodb.net/Api';


mongoose.connect(mongoDB, { useNewUrlParser: true }).then((res)=>{
    console.log(res);
    return app.listen(port, () => `Server running on port ${port} `);
})
