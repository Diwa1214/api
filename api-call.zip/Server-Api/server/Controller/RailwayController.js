const Railway = require("../Model/Railway");
const bcrypt =require("bcryptjs");
const jwt =require("jsonwebtoken");


exports.CreateRailway =(req,res,next)=>{
  const from = req.body.From;
  const to = req.body.To;
  const RailwayName = req.body.Railwayname;
 
    console.log(from);
  if(from =="" || to== ""|| RailwayName==""){
     return res.json({
       message:"Data is empty"
     })
  }
  else{
    const railway = new Railway({
      From: from,
      To: to,
      RailwayName: RailwayName
      
    })
    railway.save().then((user) => {
      return res.json({
        message: "success",
        Data: user
      })
    })

  }
   

 

   
}

exports.getTrain =(req,res,next)=>{


  Railway.find().then((data)=>{
    console.log(data);
       res.json({
         message:"Succesfully get Railway Details",
         Data:data
       })
  })
}