const mongoose = require("mongoose");
const Schema =mongoose.Schema;

const RailwaySchema = new Schema({
    From:{
        type:String
       
    },
    To:{
        type:String
    },
    RailwayName:{
        type:String
    },
    StartTime:{
        type:String
    }
})

const Railway = mongoose.model("railway",RailwaySchema);
module.exports= Railway