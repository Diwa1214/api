const express =require("express");
const router =express.Router();
const Railway =require("../Controller/RailwayController");

router.post("/CreateRailway", Railway.CreateRailway);
router.get("/fetchRailway", Railway.getTrain)
exports.Router= router